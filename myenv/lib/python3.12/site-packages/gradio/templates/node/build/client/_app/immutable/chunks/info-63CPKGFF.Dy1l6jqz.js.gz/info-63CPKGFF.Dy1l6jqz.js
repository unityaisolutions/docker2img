import{I as r,c as a}from"./mermaid-parser.core.y9B2yq-0.js";export{r as InfoModule,a as createInfoServices};
//# sourceMappingURL=info-63CPKGFF.Dy1l6jqz.js.map
