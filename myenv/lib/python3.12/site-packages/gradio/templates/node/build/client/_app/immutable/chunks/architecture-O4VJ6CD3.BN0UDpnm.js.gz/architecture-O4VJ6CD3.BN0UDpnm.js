import{A as c,e as t}from"./mermaid-parser.core.y9B2yq-0.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-O4VJ6CD3.BN0UDpnm.js.map
