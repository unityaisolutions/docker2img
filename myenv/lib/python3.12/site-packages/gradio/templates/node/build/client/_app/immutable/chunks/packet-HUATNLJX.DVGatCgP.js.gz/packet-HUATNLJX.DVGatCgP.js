import{P as c,a as r}from"./mermaid-parser.core.y9B2yq-0.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-HUATNLJX.DVGatCgP.js.map
