import{c as r,C as s,a as e,s as t}from"./chunk-JBRWN2VN.JsKFUH3Q.js";import{_ as l}from"./mermaid.core.BucEyNCN.js";var d={parser:r,get db(){return new s},renderer:e,styles:t,init:l(a=>{a.class||(a.class={}),a.class.arrowMarkerAbsolute=a.arrowMarkerAbsolute},"init")};export{d as diagram};
//# sourceMappingURL=classDiagram-3BZAVTQC.By2meGuj.js.map
