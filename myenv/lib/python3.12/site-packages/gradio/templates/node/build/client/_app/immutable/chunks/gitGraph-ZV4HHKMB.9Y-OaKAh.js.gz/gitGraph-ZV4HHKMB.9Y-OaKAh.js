import{G as a,f as G}from"./mermaid-parser.core.y9B2yq-0.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-ZV4HHKMB.9Y-OaKAh.js.map
