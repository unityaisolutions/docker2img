import{U as a,C as n}from"./mermaid.core.BucEyNCN.js";const t=(r,o)=>a.lang.round(n.parse(r)[o]);export{t as c};
//# sourceMappingURL=channel.bcFfCrzX.js.map
