import{r}from"./2.BPKDF4Xe.js";const t=o=>r[o%r.length];export{t as g};
//# sourceMappingURL=color.DOeqN_Bz.js.map
